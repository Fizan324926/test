import os
from flask import Flask, render_template, request

from config.config import *


# App object (controls web server and parsing of content)
app = Flask(__name__)

@app.route('/')
def index():

    example__int_input__min = 1  # Blocks entries < 1
    example__int_input__max = 50  # Blocks entries > 50

#     text_field = TextFieldConfig(
#                  field_name = "example_text",
#                  field_type = "text",
#                  field_label = "Example text field:")  
    
    example_int_input_errors =\
        ['(Sample error): You need to log in.  🛑',
         '(Sample error): Users of group "Jerks" are not '
         'authorized to submit this form. ❌.'
         'Please contact someone from group "nice people" for assistance.']

    example_int_input =\
               IntFieldConfig(
                   field_name="example_integer_field", 
                   field_label="Example label for an Input Field:", 
                   min_value=1, 
                   max_value="5", 
                   field_errors=example_int_input_errors)

   
    current_route =\
        request\
        .path\
        .encode('utf8',
                'ignore')
   
    example_form =\
        FormConfig(
            form_fields=[example_int_input], # ,
            #             text_field],
            form_name="example_form",
            current_route=current_route,
            submit_label="✅ Ready for the next page!")
 
    ui_elements = [example_form]
    page_config = PageConfig('page_title',
                             ui_elements=ui_elements)

    return page_config.get_content()
 

@app.route('/content')
def see_content():

    example__int_input__min = 1  # Blocks entries < 1
    example__int_input__max = 50  # Blocks entries > 50

    example_int_input_errors =\
        ['(Sample error): You need to log in.  🛑',
         '(Sample error): Users of group "Jerks" are not '
         'authorized to submit this form. ❌.'
         'Please contact someone from group "nice people" for assistance.']

    example_int_input =\
               IntFieldConfig(
                   field_name="example_integer_field", 
                   field_label="Example label for an Input Field:", 
                   min_value=1, 
                   max_value="5", 
                   field_errors=example_int_input_errors)

   
    current_route =\
        request\
        .path\
        .encode('utf8',
                'ignore')
   
    example_form =\
        FormConfig(
            form_fields=[example_int_input],
            form_name="example_form",
            current_route=current_route,
            submit_label="✅ Ready for the next page!")
 
    ui_elements = [example_form]
    page_config = PageConfig('page_title',
                             ui_elements=ui_elements)

    return page_config.get_content()
 
@app.route('/test/testl2')
def testl22():

    example__int_input__min = 1  # Blocks entries < 1
    example__int_input__max = 50  # Blocks entries > 50

    example_int_input_errors =\
        ['(Sample error): You need to log in.  🛑',
         '(Sample error): Users of group "Jerks" are not '
         'authorized to submit this form. ❌.'
         'Please contact someone from group "nice people" for assistance.']

    example_int_input =\
               IntFieldConfig(
                   field_name="example_integer_field", 
                   field_label="Example label for an Input Field:", 
                   min_value=1, 
                   max_value="5", 
                   field_errors=example_int_input_errors)

   
    current_route =\
        request\
        .path\
        .encode('utf8',
                'ignore')
   
    example_form =\
        FormConfig(
            form_fields=[example_int_input],
            form_name="example_form",
            current_route=current_route)
 
    ui_elements = [example_form]
    page_config = PageConfig('page_title',
                             ui_elements=ui_elements)

    return page_config.get_content()

if __name__ == "__main__":
    app.run(host='0.0.0.0', # Listen to outside traffic
            ssl_context=SSL_CONTEXT, # SSL
            debug=DEBUG_MODE, # True: Forward exceptiosn to the browser: False: Don't
            port=APP_CONTAINER_PORT) # Which port on this pod this will run on 
