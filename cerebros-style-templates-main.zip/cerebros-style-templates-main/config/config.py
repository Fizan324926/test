import os
# from flask import, request
from jinja2 import Template

### Globals ###

ERROR_TEXT_COLOR =\
    os.getenv('ERROR_TEXT_COLOR',
              default='#DC3545')

PAGE_BACKGROUND_COLOR = os.getenv('PAGE_BACKGROUND_COLOR',
                                  default='#f4e4f4')

FIELD_BACKGROUND_COLOR = os.getenv('FORM_BACKGROUND_COLOR',
                                   default=' #04acf3')

FIELD_FOREGROUND_COLOR = os.getenv('FORM_FOREGROUND_COLOR',
                                   default='#4cc4f3')  # 4cc4f3

FIELD_TEXT_COLOR = os.getenv('FORM_TEXT_COLOR',
                             default='#FF69B4')  # '#f4e4f4'

FORM_BORDER_COLOR = os.getenv('FORM_BORDER_COLOR',
                              default='#4cc4f3')

APP_CONTAINER_PORT = os.getenv('APP_CONTAINER_PORT',
                               default=5000)

# SSL certs to use: file paths of a registered
# SSL / TLS certificate or "adhoc" to generate a temporary
# unverified cert.
SSL_CONTEXT = os.getenv('SSL_CONTEXT',
                        default='adhoc')

CLUSTER_IP = os.getenv('CLUSTER_IP',
                       default='127.0.0.1')

# Make sure it is being represented as an int, not str
APP_CONTAINER_PORT = int(APP_CONTAINER_PORT)

DEBUG_MODE = os.getenv('DEBUG_MODE',
                       default=False)

PROTOCOL = os.getenv('PROTOCOL',
                       default="https")

FORM_METHOD = 'post'

SUBMIT_LABEL = os.getenv('SUBMIT_LABEL',
                       default="Submit")

def render_util(template, **kwargs):
    template_path = f"templates/{template}"
    with open(template_path, 'r') as template_obj:
        template_string = template_obj.read()
    
    template = Template(template_string)

    # Render the template with context data
    rendered_template = template.render(**kwargs)
    #     print(f"kwargs: {kwargs}")
    #     print(rendered_template)
    return rendered_template

# Page level Class

class PageConfig:
    PAGE_BACKGROUND_COLOR = PAGE_BACKGROUND_COLOR
    def __init__(self,
                 page_title: str,
                 ui_elements: list,
                 page_background_color=PAGE_BACKGROUND_COLOR):
        self.page_title = page_title
        self.page_background_color = page_background_color
        self.ui_elements = ui_elements

    def get_content(self):
        html_header_str = render_util(
                            "html-header.html",
                            page_title=self.page_title,
                            page_background_color=self.page_background_color)
        html_body_list = [element.get_content()
                          for element in self.ui_elements]
        html_body_str = "\n".join(html_body_list)
        html_footer_str = render_util("html-footer.html")

        html_content_list = [html_header_str,
                             html_body_str,
                             html_footer_str]
        
        
        html_content_list = "\n".join(html_content_list)
        
        return html_content_list

       

# Form config Form level class

class FormConfig:
    FORM_METHOD = FORM_METHOD
    APP_CONTAINER_PORT = APP_CONTAINER_PORT
    CLUSTER_IP = CLUSTER_IP
    PROTOCOL = PROTOCOL
    FIELD_BACKGROUND_COLOR = FIELD_BACKGROUND_COLOR
    SUBMIT_LABEL = SUBMIT_LABEL

    def __init__(self,
                 form_fields: list,
                 form_name: str,
                 current_route: str,  # Pass in via requests.path().
                 submit_label = SUBMIT_LABEL,
                 form_method=FORM_METHOD,
                 field_background_color=FIELD_BACKGROUND_COLOR):
        self.form_fields = form_fields
        self.form_name = form_name
        self.current_route = current_route
        self.form_target_route = f"{current_route}-submit"
        self.form_target_host = self.remove_all(
            self.CLUSTER_IP, ["http", "https", ":", "/"])
        self.form_host_target_protocol = PROTOCOL
        self.form_target_port = self.APP_CONTAINER_PORT
        if self.form_target_host in [self.CLUSTER_IP, "127.0.0.1", "localhost"]:
            self.form_host_target_protocol = ""
            self.separator1 = ""
            self.form_target_host = ""
            self.separator2 =  ""
            self.form_target_port = ""
        else:
            self.separator1 = "://"
            self.separator2 =  ":"
            self.form_target_port = self.form_target_port
        self.form_method = form_method
        self.form_action = f"{self.form_host_target_protocol}{self.separator1}{self.form_target_host}{self.separator2}{self.form_target_port}{self.form_target_route}"
        self.field_background_color = field_background_color
        self.submit_label = submit_label
        
    def remove_all(self, s: str, l: list, repl: str = ""):
        """Deletes or otherwise replaces multiple annoying substrings from a string in one call """
        for st in l:
            s = s.replace(st, repl)
        return s

    def get_content(self):
        form_header_str = render_util('form-header.html',
                                       form_name=self.form_name,
                                       form_action=self.form_action,
                                       form_method=self.form_method,
                                       field_background_color=self.field_background_color)
        form_fields_list = [field.get_content() for field in self.form_fields]
        form_fields_str = "\n".join(form_fields_list)
        form_footer_str = render_util('form-footer.html',
                                      submit_label=self.submit_label)

        content_list = [form_header_str, form_fields_str, form_footer_str]
        content_str = "\n".join(content_list)
        return content_str

# Field level base class for all fields

class FieldConfig:
    FIELD_FOREGROUND_COLOR
    FIELD_BACKGROUND_COLOR
    FIELD_TEXT_COLOR
    ERROR_TEXT_COLOR
    FORM_BORDER_COLOR

    def __init__(self,
                 field_name: str,
                 field_type: str,
                 field_label: str,
                 field_errors=[],
                 field_background_color=FIELD_BACKGROUND_COLOR,
                 field_foreground_color=FIELD_FOREGROUND_COLOR,
                 field_text_color=FIELD_TEXT_COLOR,
                 field_errors_color=ERROR_TEXT_COLOR,
                 field_border_color=FORM_BORDER_COLOR):
        self.field_name = field_name
        self.field_type = field_type
        self.field_label = field_label
        self.field_errors = field_errors
        self.field_background_color = field_background_color
        self.field_foreground_color = field_foreground_color
        self.field_text_color = field_text_color
        self.field_errors_color = field_errors_color
        self.field_border_color = field_border_color

# Child of field level class for integer fields

class IntFieldConfig(FieldConfig):
    FIELD_FOREGROUND_COLOR
    FIELD_BACKGROUND_COLOR
    FIELD_TEXT_COLOR
    ERROR_TEXT_COLOR
    FORM_BORDER_COLOR

    def __init__(self,
                 field_name,
                 field_label,
                 min_value,
                 max_value,
                 field_errors,
                 field_type='number'):

        # Should defaiult to global configs 
        # field_background_color,
        # field_foreground_color,
        # field_text_color,
        # field_errors_color,
        # field_border_color,
        
        super().__init__(field_name=field_name,
                         field_type=field_type,
                         field_label=field_label,
                         field_errors=field_errors)
        
        self.min_value = min_value
        self.max_value = max_value
        

    def get_content(self):
        return render_util('int-field.html',
                           field_name=self.field_name,
                           field_label=self.field_label,
                           min_value=self.min_value,
                           max_value=self.max_value,
                           field_errors=self.field_errors,
                           field_background_color=self.field_background_color,
                           field_foreground_color=self.field_foreground_color,
                           field_text_color=self.field_text_color,
                           field_errors_color=self.field_errors_color)
