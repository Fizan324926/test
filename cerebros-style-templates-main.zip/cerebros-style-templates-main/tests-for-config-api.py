

# Templates requyired

# html-header.html +
# html_footer.html -
# form-header.html -
# form-footer.html -
# int-field.html -

from config.config import *

# Add tests ...

test_0 = "test under development..."

print(f"Test: {test_0}")

if __name__ == "__main__":

    PageConfig("Silly page",
               ui_elements=[])

# # FORM name attribute <form name="{..}"...>
# # THIS ONE MUST BE A VALID PYTHON VARIABLE NAME
#
# ####### Field level args usually changed #######
# ####### For each field                   #######
#
# # Convention for naming form input fields (separate
# # hirarchcy levles with double underscore _ _):
#
# # [form's name]__[datatype]__[field property name]
#
# # This may be confusing at first, but with 50 pages of UI content,
# # Being able to copy and paste this, duplicate the template,
# # and just comment out or erase everything you don't need
# # will make this a lot faster and easier ...
#
# # Params for the integer HTML input:
#
# # <label for="{example__int_input__name}">{{example__int_input__label}}</label>
example__int_input__min = 1  # Blocks entries < 1
example__int_input__max = 50  # Blocks entries > 50
#
# # If the user was redirected back to the form
# # because of a bad past submission, this will
# # flag errors.

# Required fields:

example_int_input_errors =\
    ['(Sample error): You need to log in.  🛑',
     '(Sample error): Users of group "Jerks" are not '
     'authorized to submit this form. ❌.'
     'Please contact someone from group "nice people" for assistance.']

example_int_input =\
           IntFieldConfig(
               field_name="example_integer_field", 
               field_label="Example label for an Input Field:", 
               min_value=1, 
               max_value="5", 
               field_errors=example_int_input_errors)


example_form =\
    FormConfig(
        form_fields=[example_int_input],
        form_name="example_form",
        current_route='/num-inputs',
        submit_label="✅ Ready for the next page!")

ui_elements = [example_form]
page_config = PageConfig('page_title',
                         ui_elements=ui_elements)

page_content = page_config.get_content()
print("Page content is:")
print(page_content)
