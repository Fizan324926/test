# cerebros-style-templates

## Contributing guidelines:

1. With the exception, that the public may not contribute to our private repositories: Here is a summary of the process to contribute:

- All resources will be created in europe-west4.
- https://github.com/david-thrower/cerebros-core-algorithm-alpha/blob/main/CONTRIBUTING.md ... 
- We do have one additional step. before making a git push, please update the **tag on the image element on the yaml file for the component** you are updating. On the yaml file in the root directory of this repository there should be a is string of text on the line labeled `image: [some-url:some-tag]`. For example it may look like: `    image: europe-west4-docker.pkg.dev/cerebros-enterprise-site/test-ux/new-test:br6-0001`. In this case, the tag is `br6-0001`. Before pushing a change to a remote branch, update the tag as br-[branch-number]-[serial number of push made]. This makes it easy to cross reference container updates with changes to the development channel.

2. Additionally, this is also detailed in Cerebros SOP-0001: Change control and SOP-0004: SOP for CICD,production build process, and product release.
3. Lastly, SOP-0006: "Bring your own device and 3rd party corporate partner device policy" being implemented at the time of this writing, provides that unnescessary persistent local copies should not be maintained, your laptop should keep ephemeral copies encrypted at rest and in transit, and you should exercise a reasonable standard of care to maintain the confidentiality of our confidential data, including our source code. Among others, you should maintain a subscription with an approved security monitoring service (e.g. Ubuntu Pro Livepatch, which is free) ... **(also note that Kaspersky and other vendors harbored in Russia or China, as well as any US export restricted locale or entity which the US, EU, GB, or CH governments have disrecommnded theirn citizens from using technologies originating from is not allowed)**, maintain password protections on your personal machine, automatic screen lock when idle, among other typical reasobnable expectations of protection which a typical stable corporate development operation would expect.

## Connecting to the repositories **for pushing code changes**:

See the directions below for creating a fine - grained token. To push code to a branch **other than the default branch**, follow the same instructions, except name the token soemthing that includes the repo name and ends with **-rw** (so we know it's a **read - write access token**), and give it read + write access to the **Contents** of the repository and nothing else. Please do not give it additional permsissions, unless necessary, and this necessity was discovered by a permissions denied error encountered while updating something you have been personally assigned by Cerebros to update. We are pursuing a SOC II ceritification. So doing may cause our security setting monitoring to flag errors that both the auditor and our customers will see. **Also remember that committing or pushing to the default branch is NEVER permitted. All proposed changes to the default branch must be submitted as a pull request and approved by the CTO of Cerebros or an internal developer of L5 appointment or greater.** Additioanlly, **please NEVER** use this token as a service account to copy the code into a development Kubernetes cluster or server. Create a separate token **HAVING READ ONLY** access for that. Lastly, please do not copy any access token into a repository. Maintain these in a secret manager or an encrypted file or in GIT on your IDE environment.  

## Instructions to deploy this app and others made from this template on a kubernetes cluster:

Step one, create a GitHub fine-grained access token with **read-only** access to the repository **Contents** only:

1. Go to your GitHub account settings by clicking on your profile picture in the top right corner of the page and selecting "Settings" from the dropdown menu.

![readme-assets/you-github.png](readme-assets/you-github.png)

![readme-assets/github-settings.png](readme-assets/github-settings.png)

2. In the left sidebar, click on "Developer settings" and then click on "Personal access tokens".

![readme-assets/developer-settings.png](readme-assets/developer-settings.png)

![readme-assets/personal-access-tokens.png](readme-assets/personal-access-tokens.png)

3. Click on the "fine-grained access token" button.

![readme-assets/fine-grained-access-token.png](readme-assets/fine-grained-access-token.png)

4. Click "generate new token".

![readme-assets/generate-new-token.png](readme-assets/generate-new-token.png)

5. You should be prompted for 2-factor authentication. 

![readme-assets/2-factor-auth.png])(readme-assets/2-factor-auth.png)

6. Name the token a name **that includes the name of the repository** and also ends with **-ro** (so we know it's a **read only token**). **PLEASE DO NOT** use the developer token that you created to puch changes to the repository on Github from your local repository. Using a -rw access token as a service account to copy in a repository to a development kubernetes cluster is a terrible security practice. Create another token here that has read only access and is only used for copying the code to the cluster. Select read only access for the "Contents" of the repository you are working on. This will also add read only permeission to the repository's metadata automatically, which is required.  Please make sure this is not taking on any additional privelages other than:
    1. Read only access to the repository's "Contents".
    2. Read only access to the repository's "Metadata".
    3. Please do not keep unencrypted copies of thois after you completed the step "Cloning the repository". 

![readme-assets/access-token-settings-1.png](readme-assets/access-token-settings-1.png)

![readme-assets/read-only.png](readme-assets/read-only.png)

7. Next, click on the "Generate token" button at the bottom of the page.

8. The token will be displayed on the next page. Proceed to the next step task "cloning the repository":

## Set up a Kubernetes cluster and Clone the repository **with read only access**
 
1. Log into the GCP project you have been authorized to work in for this project.
2. Go to the main console of the GKE (Google Kubernetes Engine) page, create a cluster using the defaults for everything. The only exception is to make sure that it is set up to allow HTTPS connections. This may be a default setting. If you already have a cluster running, and you are **certain** it does not have another version of the same project on it, then use the cluster you already have running. **for applications with Kubeflow as a component, you must set up a user managed cluster, not an autopilot cluster. For everythign else, use an autopilot cluster, as will minimize idle resources**.
3. While you are still on the Google Kubernetes Engine console page, and while you are waiting for the cluster to be provisioned. Click on cloud shell. (Shell logo on the top right of the screen.)
4. Cloud shell opens a shell terminal as a pop-up: Run these commands:
    1. `git clone https://{your-github-username}:{THE-TOKEN-YOU-JUST-CREATED}@{this-repository's-url}`
    2. `git pull`
    3. If you are testing your changes, run `git checkout {the branch you were committing your changes to}`. If you are trying to see the curent stable branch, skip this step. Note, that you should **not** merge your changes into the **default branch** that is (**main / master**) until you have approval form the CTO or an L5 or higher developer if one is not availible.
    4. If you are testing your changes, run `git pull origin {the branch you were committing your changes to}`. If you are trying to see the curent stable branch, skip this step. Note, that you should **not** merge your changes into the **default branch** that is (**main / master**) until you have approval form the CTO or an L5 or higher developer if one is not availible.
    5. Run the command `cd {name-of-this-repository}`.    

## Build the container and push it to the project's local container image registry

1. Make sure you are on cloud shell and in the root dorectory of the project's repository and on the correct branch that you have been pushing changes to. 
    1. Get the build's image URI and tag. To do this, run the command: `cat uitest.yaml | grep pkg`. You should get a response that may look like: 
        1. `          image: europe-west4-docker.pkg.dev/cerebros-enterprise-site/test-ux/new-test:br6-0001`. 
        2. In this example, the image URI is `europe-west4-docker.pkg.dev/cerebros-enterprise-site/test-ux/new-test` and the tag is `br6-0001`
2. Build the image. To do this: 
    1. Run the command: `docker build -t {IMAGE URI}:{TAG} .` ... Note that the '.' on the end is **not** a typographical error. it is part of the command. In this case, the command would be:
        1. `docker build -t europe-west4-docker.pkg.dev/cerebros-enterprise-site/test-ux/new-test:br6-0001 .`
3. Push the image to the project's local container image registry. To do this:
    1. Run the command: `docker push {IMAGE URI}:{TAG}` 
        1. In this case this would be: `docker push europe-west4-docker.pkg.dev/cerebros-enterprise-site/test-ux/new-test:br6-0001`

## Connect to your cluster and deploy the app

1. Click on the cluster once it is up and running. Click the "connect" button. It will give you a command to copy. Paste this command **into cloud shell [or a vm on your vpc]**. Please do not use that on your local machine. This would introduce serious security vulnerabilities to your machine.
2. There should be a YAML file. Run the command `ls` to get its name. Now run:
    1. `kubectl apply -f {THAT-FILE-NAME}`
3. Run `kubectl get namespace` and you should see a namespace listed that is similar to the name of the project you are working in.
5. Find the ingress endpoint and make sure the pods are running and in good health: 
    1. Run the command: `kubectl get all -n {the namespace that gave you}`. 
    2. You should see something like this:

```
# This line is the pod section            (* READY is number of healthy pods / number of pods specified)       
NAME                                       READY   STATUS    RESTARTS   AGE
pod/new-test-deployment-{sha redacted}      1/1     Running   0          5m14s

# Services and ingress section                          (* EXTERNAL-IP - where to reach your app from your browser; 
#                                                                       PORT(S), Access via the First one)
NAME                       TYPE           CLUSTER-IP       EXTERNAL-IP  PORT(S)             AGE
service/new-test-service   LoadBalancer   10.xx.xxx.xxx   34.xx.xx.xx  443:{redacted}/TCP   3m10s

NAME                                  READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/new-test-deployment   1/1     1            1           5m14s

NAME                                             DESIRED   CURRENT   READY   AGE
replicaset.apps/new-test-deployment-67f9f85797   1         1         1       5m14s

```
6. Continued, find the ingress for the app and connect to it.
    3. You should see an entry in the section pods, which lists the pod(s) for the component you are working on. Make sure the column READY shows the same number of healthy pods as the manifest is requesting. It may take a few minutes to provision, especially if the cluster is saturated with other work or under-provisioned.
    4. You should see an entry under the section "services" for an ingress of TYPE LoadBalancer. You should see an **EXTERNAL-IP address** listed. Copy this and in your browser paste it in as:  `https://{THAT-IP-ADDRESS}:443`. 
    5. Also, note that the same information can be viewed in a GUI on the GKE console, but it is scattered between 2 differenbt places: The pods are found on the [workloads] tab. The LoadBalancer address is found under the [services and ingress tab] > services.
    6. If the app has a specific web URI route that you are trying to test (e.g. https://{url}/models ), then append `/{THAT-ROUTE}` to it. 
        1. Be mindful that most apps, once authentication and authorization are applied, it will probably not accept requests that have not passed through the login page first then accessed through the navigation buttons and links throughout the app.
